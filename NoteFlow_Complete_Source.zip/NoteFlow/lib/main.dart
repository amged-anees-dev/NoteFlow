import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = NotesController();
  await controller.load();
  runApp(NoteFlowApp(controller: controller));
}

class Note {
  final String id;
  String title;
  String content;
  String category;
  int color;
  bool pinned;
  bool deleted;
  DateTime createdAt;
  DateTime updatedAt;

  Note({
    required this.id,
    required this.title,
    required this.content,
    this.category = 'عام',
    this.color = 0xFFF3F4F6,
    this.pinned = false,
    this.deleted = false,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'content': content, 'category': category,
    'color': color, 'pinned': pinned, 'deleted': deleted,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory Note.fromJson(Map<String, dynamic> j) => Note(
    id: j['id'], title: j['title'], content: j['content'],
    category: j['category'] ?? 'عام', color: j['color'] ?? 0xFFF3F4F6,
    pinned: j['pinned'] ?? false, deleted: j['deleted'] ?? false,
    createdAt: DateTime.parse(j['createdAt']),
    updatedAt: DateTime.parse(j['updatedAt']),
  );
}

class NotesController extends ChangeNotifier {
  final List<Note> notes = [];
  bool darkMode = false;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    darkMode = p.getBool('darkMode') ?? false;
    final raw = p.getString('notes');
    if (raw != null) {
      notes.addAll((jsonDecode(raw) as List).map((e) => Note.fromJson(e)));
    }
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('darkMode', darkMode);
    await p.setString('notes', jsonEncode(notes.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  Future<void> upsert(Note note) async {
    final i = notes.indexWhere((n) => n.id == note.id);
    if (i >= 0) notes[i] = note; else notes.add(note);
    await save();
  }

  Future<void> trash(Note note) async { note.deleted = true; note.pinned = false; await save(); }
  Future<void> restore(Note note) async { note.deleted = false; await save(); }
  Future<void> deleteForever(Note note) async { notes.removeWhere((n) => n.id == note.id); await save(); }
  Future<void> toggleTheme(bool value) async { darkMode = value; await save(); }
}

class NoteFlowApp extends StatelessWidget {
  final NotesController controller;
  const NoteFlowApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (_, __) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NoteFlow',
      themeMode: controller.darkMode ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF635BFF), brightness: Brightness.light),
      darkTheme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF8B85FF), brightness: Brightness.dark),
      home: Directionality(textDirection: TextDirection.rtl, child: HomePage(controller: controller)),
    ),
  );
}

class HomePage extends StatefulWidget {
  final NotesController controller;
  const HomePage({super.key, required this.controller});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String query = '';
  String category = 'الكل';

  List<Note> get visible {
    Iterable<Note> result = widget.controller.notes.where((n) => tab == 2 ? n.deleted : !n.deleted);
    if (tab == 1) result = result.where((n) => n.pinned);
    if (category != 'الكل') result = result.where((n) => n.category == category);
    if (query.isNotEmpty) result = result.where((n) =>
      n.title.toLowerCase().contains(query.toLowerCase()) ||
      n.content.toLowerCase().contains(query.toLowerCase()));
    final list = result.toList();
    list.sort((a,b) {
      if (a.pinned != b.pinned && tab == 0) return a.pinned ? -1 : 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final categories = ['الكل', ...{...c.notes.where((n)=>!n.deleted).map((n)=>n.category)}];
    final titles = ['ملاحظاتي', 'المثبتة', 'سلة المحذوفات'];

    return Scaffold(
      appBar: AppBar(
        title: Text(titles[tab], style: const TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(c.darkMode ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
            onPressed: () => c.toggleTheme(!c.darkMode),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'settings') Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(controller: c)));
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'settings', child: Text('الإعدادات')),
            ],
          )
        ],
      ),
      body: Column(
        children: [
          if (tab != 2) Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: InputDecoration(
                hintText: 'ابحث في ملاحظاتك...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
              ),
            ),
          ),
          if (tab == 0) SizedBox(
            height: 48,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => ChoiceChip(
                label: Text(categories[i]),
                selected: category == categories[i],
                onSelected: (_) => setState(() => category = categories[i]),
              ),
            ),
          ),
          Expanded(
            child: visible.isEmpty
              ? _EmptyState(tab: tab)
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                  itemCount: visible.length,
                  itemBuilder: (_, i) => NoteCard(
                    note: visible[i], controller: c, trashMode: tab == 2,
                    onChanged: () => setState(() {}),
                  ),
                ),
          ),
        ],
      ),
      floatingActionButton: tab == 2 ? null : FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => NoteEditor(controller: c)));
          setState(() {});
        },
        icon: const Icon(Icons.add_rounded), label: const Text('ملاحظة جديدة'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.notes_outlined), selectedIcon: Icon(Icons.notes), label: 'الملاحظات'),
          NavigationDestination(icon: Icon(Icons.push_pin_outlined), selectedIcon: Icon(Icons.push_pin), label: 'المثبتة'),
          NavigationDestination(icon: Icon(Icons.delete_outline), selectedIcon: Icon(Icons.delete), label: 'المحذوفات'),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final int tab;
  const _EmptyState({required this.tab});
  @override Widget build(BuildContext context) {
    final data = [
      (Icons.note_alt_outlined, 'لا توجد ملاحظات بعد', 'ابدأ بإضافة أول ملاحظة لك.'),
      (Icons.push_pin_outlined, 'لا توجد ملاحظات مثبتة', 'ثبّت الملاحظات المهمة لتظهر هنا.'),
      (Icons.delete_outline, 'سلة المحذوفات فارغة', 'الملاحظات المحذوفة ستظهر هنا.'),
    ][tab];
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(data.$1, size: 72, color: Theme.of(context).colorScheme.primary),
      const SizedBox(height: 16),
      Text(data.$2, style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      Text(data.$3, textAlign: TextAlign.center),
    ]));
  }
}

class NoteCard extends StatelessWidget {
  final Note note;
  final NotesController controller;
  final bool trashMode;
  final VoidCallback onChanged;
  const NoteCard({super.key, required this.note, required this.controller, required this.trashMode, required this.onChanged});

  @override
  Widget build(BuildContext context) => Card(
    color: Color(note.color),
    elevation: 0,
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () async {
        if (!trashMode) {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => NoteEditor(controller: controller, note: note)));
          onChanged();
        }
      },
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(note.title.isEmpty ? 'بدون عنوان' : note.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
            if (note.pinned && !trashMode) const Icon(Icons.push_pin, size: 18),
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'pin') { note.pinned = !note.pinned; note.updatedAt = DateTime.now(); await controller.save(); }
                if (v == 'trash') await controller.trash(note);
                if (v == 'restore') await controller.restore(note);
                if (v == 'delete') await controller.deleteForever(note);
                onChanged();
              },
              itemBuilder: (_) => trashMode
                ? const [
                    PopupMenuItem(value: 'restore', child: Text('استعادة')),
                    PopupMenuItem(value: 'delete', child: Text('حذف نهائي')),
                  ]
                : [
                    PopupMenuItem(value: 'pin', child: Text(note.pinned ? 'إلغاء التثبيت' : 'تثبيت')),
                    const PopupMenuItem(value: 'trash', child: Text('نقل إلى سلة المحذوفات')),
                  ],
            ),
          ]),
          if (note.content.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(note.content, maxLines: 3, overflow: TextOverflow.ellipsis),
          ],
          const SizedBox(height: 12),
          Row(children: [
            Icon(Icons.folder_outlined, size: 15),
            const SizedBox(width: 4),
            Text(note.category, style: const TextStyle(fontSize: 12)),
            const Spacer(),
            Text(DateFormat('yyyy/MM/dd – HH:mm').format(note.updatedAt), style: const TextStyle(fontSize: 11)),
          ]),
        ]),
      ),
    ),
  );
}

class NoteEditor extends StatefulWidget {
  final NotesController controller;
  final Note? note;
  const NoteEditor({super.key, required this.controller, this.note});
  @override State<NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<NoteEditor> {
  late final TextEditingController title;
  late final TextEditingController content;
  late final TextEditingController category;
  int selectedColor = 0xFFF3F4F6;
  bool pinned = false;

  final colors = [0xFFF3F4F6, 0xFFFFE9A8, 0xFFCDECCF, 0xFFCFE8FF, 0xFFFFD6D6, 0xFFE8D7FF];

  @override void initState() {
    super.init();
    final n = widget.note;
    title = TextEditingController(text: n?.title ?? '');
    content = TextEditingController(text: n?.content ?? '');
    category = TextEditingController(text: n?.category ?? 'عام');
    selectedColor = n?.color ?? selectedColor;
    pinned = n?.pinned ?? false;
  }

  @override void dispose() { title.dispose(); content.dispose(); category.dispose(); super.dispose(); }

  Future<void> saveNote() async {
    if (title.text.trim().isEmpty && content.text.trim().isEmpty) {
      Navigator.pop(context); return;
    }
    final now = DateTime.now();
    final note = widget.note ?? Note(
      id: now.microsecondsSinceEpoch.toString(), title: '', content: '',
      createdAt: now, updatedAt: now,
    );
    note.title = title.text.trim();
    note.content = content.text.trim();
    note.category = category.text.trim().isEmpty ? 'عام' : category.text.trim();
    note.color = selectedColor;
    note.pinned = pinned;
    note.updatedAt = now;
    await widget.controller.upsert(note);
    if (mounted) Navigator.pop(context);
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.note == null ? 'ملاحظة جديدة' : 'تعديل الملاحظة'),
      actions: [
        IconButton(icon: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined), onPressed: () => setState(()=>pinned=!pinned)),
        IconButton(icon: const Icon(Icons.check_rounded), onPressed: saveNote),
      ],
    ),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        TextField(controller: title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold), decoration: const InputDecoration(hintText: 'العنوان', border: InputBorder.none)),
        TextField(controller: content, maxLines: null, expands: true, textAlignVertical: TextAlignVertical.top, decoration: const InputDecoration(hintText: 'ابدأ بالكتابة...', border: InputBorder.none)),
        const SizedBox(height: 8),
        TextField(controller: category, decoration: InputDecoration(labelText: 'التصنيف', prefixIcon: const Icon(Icons.folder_outlined), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)))),
        const SizedBox(height: 12),
        Row(children: [
          const Text('لون الملاحظة: '),
          ...colors.map((c) => GestureDetector(
            onTap: () => setState(()=>selectedColor=c),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4), width: 28, height: 28,
              decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle, border: Border.all(color: selectedColor == c ? Theme.of(context).colorScheme.primary : Colors.grey)),
            ),
          )),
        ]),
      ]),
    ),
  );
}

class SettingsPage extends StatelessWidget {
  final NotesController controller;
  const SettingsPage({super.key, required this.controller});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الإعدادات')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      SwitchListTile(
        value: controller.darkMode,
        onChanged: controller.toggleTheme,
        secondary: const Icon(Icons.dark_mode_outlined),
        title: const Text('الوضع الداكن'),
        subtitle: const Text('تغيير مظهر التطبيق'),
      ),
      const Divider(),
      ListTile(
        leading: const Icon(Icons.info_outline),
        title: const Text('حول التطبيق'),
        subtitle: const Text('NoteFlow الإصدار 1.0.0'),
      ),
    ]),
  );
}
